
import static java.util.Arrays.asList;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import org.bson.Document;

import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoDatabase;



public class newCollection {
	public static void main(String[] args) throws IOException {
		// Build a MongoClient instance to connect the MongoDB
		MongoClient client = new MongoClient();
        // Build an unchangeable MongoDatabase instance to connect the specific Database in MongoDB
		final MongoDatabase db = client.getDatabase("yiz");
		/*
		 * query: db.movies.aggregate([{"$unwind":"$Genres"} ])
		 */
        
        // use iterable（API）to implement the query of MongoDB
		AggregateIterable<Document> iterable = db.getCollection("movies")//get the data from collection movies
				.aggregate(asList(
                        // set the name of values
                        new Document("$project", new Document("MovieID", 1).append("Genres", 1)),
						new Document("$unwind", "$Genres")));
        // create a temperate collection to unwind the original collections,movies
        // create a new collection to storage the data after unwinding the original collections
		if (db.getCollection("temp_movies") == null) {
			db.createCollection("temp_movies");
		}else{
			db.getCollection("temp_movies").drop();
			db.createCollection("temp_movies");
		}
		iterable.forEach(new Block<Document>() {
			@Override
            // add the tuples with MovieID and Genre to the collection
			public void apply(final Document document) {
				db.getCollection("temp_movies").insertOne(
						new Document("MovieID", document.get("MovieID")).append("Genres", document.get("Genres")));
			}
		});
		/*
		 * query: db.temp_movies.aggregate([
		 * {"$group":{"_id":"$Genres","count":{"$sum":1}}} ])
		 */
        
        // use iterable（API）to implement the query of MongoDB
		AggregateIterable<Document> iterable2 = db.getCollection("temp_movies")//get the data from collection movies
              .aggregate(asList(new Document("$group", new Document("_id", "$Genres")
                             // get the counts of movies of each Genre
                             .append("count", new Document("$sum", 1)))));

    }
}
